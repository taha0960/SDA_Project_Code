CREATE DATABASE SDA;
USE SDA;
CREATE TABLE User (
    username VARCHAR(50) PRIMARY KEY,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(100),
    age INT,
    height DOUBLE,
    weight DOUBLE,
    activityLevel INT,
    dietaryPreferences TEXT,
    allergies TEXT
);

CREATE TABLE Category (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) UNIQUE NOT NULL
);

INSERT INTO Category (name) VALUES 
('Cardio'),
('Strength Training'),
('Yoga'),
('Pilates'),
('HIIT');

DROP TABLE Resource;

CREATE TABLE Resource (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    type VARCHAR(50),
    content TEXT,
    image BLOB,
    category VARCHAR(100),
    link VARCHAR(255),  -- New field for the link
    FOREIGN KEY (category) REFERENCES Category(name) ON DELETE CASCADE
);

INSERT INTO Resource (title, type, content, image, category, link) VALUES
('Running Basics', 'Guide', 'A guide to start running effectively.', NULL, 'Cardio', 'https://www.youtube.com/watch?v=kVnyY17VS9Y'),
('Treadmill Workouts', 'Routine', 'Best practices for treadmill training.', NULL, 'Cardio', 'https://www.youtube.com/watch?v=EZ7OkjYGhdY'),
('Strength Basics', 'Article', 'Learn the basics of strength training.', NULL, 'Strength Training', 'https://www.youtube.com/watch?v=WIHy-ZnSndA'),
('Yoga for Beginners', 'Video', 'An introduction to yoga for newcomers.', NULL, 'Yoga', 'https://www.youtube.com/watch?v=jtYZDrYL634'),
('Advanced Yoga Poses', 'Image', 'A gallery of advanced yoga poses.', NULL, 'Yoga', 'https://www.youtube.com/watch?v=higAEnYNl-k'),
('HIIT Workouts', 'Routine', 'High-Intensity Interval Training routines.', NULL, 'HIIT', 'https://www.youtube.com/watch?v=cbKkB3POqaY'),
('Pilates Essentials', 'Guide', 'Core principles of Pilates exercises.', NULL, 'Pilates', 'https://www.youtube.com/watch?v=nfMALE8WdoE');

CREATE TABLE Goal (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    startWeight INT,
    goalWeight INT,
    currentWeight INT,
    progress DOUBLE,
    FOREIGN KEY (username) REFERENCES User(username) ON DELETE CASCADE
);

CREATE TABLE events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    location VARCHAR(255) NOT NULL,
    cost VARCHAR(50),
    category VARCHAR(50) NOT NULL,
    event_date DATE NOT NULL,
    difficulty VARCHAR(50) NOT NULL
);

