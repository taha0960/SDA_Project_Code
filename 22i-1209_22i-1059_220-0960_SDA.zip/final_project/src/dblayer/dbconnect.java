package dblayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import blayer.User;
import blayer.goal;
import blayer.resource;

public class dbconnect {
    private static final String URL = "jdbc:mysql://localhost:3306/SDA";
    private static final String USER = "root";
    private static final String PASSWORD = "Hamza123@";

    // Singleton instance
    private static dbconnect instance;

    // Private constructor to prevent instantiation from outside
    private dbconnect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    // Method to get the singleton instance
    public static synchronized dbconnect getInstance() {
        if (instance == null) {
            instance = new dbconnect();
        }
        return instance;
    }

    // Method to get the database connection
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public void addUser(User user) {
        String query = "INSERT INTO User (username, password, name, age, height, weight, activityLevel, dietaryPreferences, allergies) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getPassword());
            pstmt.setString(3, user.getName());
            pstmt.setInt(4, user.getAge());
            pstmt.setDouble(5, user.getHeight());
            pstmt.setDouble(6, user.getWeight());
            pstmt.setInt(7, user.getActivityLevel());
            pstmt.setString(8, String.join("\n", user.getDietaryPreferences()));
            pstmt.setString(9, String.join("\n", user.getAllergies()));
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean loginUser(String username, String password) {
        String query = "SELECT COUNT(*) FROM User WHERE username = ? AND password = ?";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            try (ResultSet rs = pstmt.executeQuery()) {
                rs.next();
                int count = rs.getInt(1);
                return count == 1; // If count is 1, the login is successful
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Return false in case of any SQL exception
        }
    }

    public User getUserByUsername(String username) {
        String query = "SELECT * FROM User WHERE username = ?";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, username);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new User(
                            rs.getString("username"),
                            rs.getString("password"),
                            rs.getString("name"),
                            rs.getInt("age"),
                            rs.getDouble("height"),
                            rs.getDouble("weight"),
                            rs.getInt("activityLevel"),
                            Arrays.asList(rs.getString("dietaryPreferences").split("\n")),
                            Arrays.asList(rs.getString("allergies").split("\n"))
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public void updateUser(User user) {
        String query = "UPDATE User SET password = ?, name = ?, age = ?, height = ?, weight = ?, activityLevel = ?, dietaryPreferences = ?, allergies = ? WHERE username = ?";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, user.getPassword());
            pstmt.setString(2, user.getName());
            pstmt.setInt(3, user.getAge());
            pstmt.setDouble(4, user.getHeight());
            pstmt.setDouble(5, user.getWeight());
            pstmt.setInt(6, user.getActivityLevel());
            pstmt.setString(7, String.join("\n", user.getDietaryPreferences()));
            pstmt.setString(8, String.join("\n", user.getAllergies()));
            pstmt.setString(9, user.getUsername());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
    public void deleteUser(String username) {
        String query = "DELETE FROM User WHERE username = ?";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, username);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public List<String> getAllCategoryNames() {
        List<String> categoryNames = new ArrayList<>();
        String query = "SELECT name FROM Category";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                categoryNames.add(rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return categoryNames;
    }

    // Method to get resources by category from the database
    public List<resource> getResourcesByCategory(String categoryName) {
        List<resource> resources = new ArrayList<>();
        String query = "SELECT title, type, content, image, link FROM Resource WHERE category = ?";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, categoryName);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    String title = rs.getString("title");
                    String type = rs.getString("type");
                    String content = rs.getString("content");
                    byte[] image = rs.getBytes("image");
                    String link = rs.getString("link");  // Fetch the link

                    // Create a resource object with the additional link field
                    resource resource = new resource(title, type, content, image, link);
                    resources.add(resource);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resources;
    }
    
    public goal getGoalByUsername(String username) {
        String query = "SELECT * FROM Goal WHERE username = ?";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, username);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new goal(
                            rs.getInt("startWeight"),
                            rs.getInt("goalWeight"),
                            rs.getInt("currentWeight"),
                            rs.getDouble("progress"),
                            rs.getString("username")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public void addGoalForUser(String username, goal newGoal) {
        String query = "INSERT INTO Goal (startWeight, goalWeight, currentWeight, progress, username) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, newGoal.getStartWeight());
            pstmt.setInt(2, newGoal.getGoalWeight());
            pstmt.setInt(3, newGoal.getCurrentWeight());
            pstmt.setDouble(4, newGoal.getProgress());
            pstmt.setString(5, username);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void removeGoalForUser(String username) {
        String query = "DELETE FROM Goal WHERE username = ?";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, username);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void updateGoal(goal updatedGoal) {
        String query = "UPDATE Goal SET startWeight = ?, goalWeight = ?, currentWeight = ?, progress = ? WHERE username = ?";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, updatedGoal.getStartWeight());
            pstmt.setInt(2, updatedGoal.getGoalWeight());
            pstmt.setInt(3, updatedGoal.getCurrentWeight());
            pstmt.setDouble(4, updatedGoal.getProgress());
            pstmt.setString(5, updatedGoal.getUsername());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
}
