package application.controller;

import blayer.session;
import dblayer.dbconnect;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;
import blayer.goal;

public class goalcontroller {

    @FXML
    private Button backButton;

    @FXML
    private Label titleLabel;

    @FXML
    private Label progressLabel;

    @FXML
    private Label currentLabel;

    @FXML
    private Label currentValueLabel;

    @FXML
    private Label goalLabel;

    @FXML
    private Label goalValueLabel;

    @FXML
    private Label progressTextLabel;

    @FXML
    private Label progressValueLabel;

    @FXML
    private ImageView machineImageView;

    @FXML
    private ProgressBar progressBar;

    @FXML
    private Button addButton;

    @FXML
    private Button removeButton;

    @FXML
    private Button updateButton;
    
    private goal goal;

    @FXML
    public void initialize() {
    	 String username = session.getUser();

    	    // Fetch user's goals
    	    goal = fetchUserGoals(username);

    	    // Update UI with goal details if goals exist, otherwise display a message
    	    if (goal != null) {
    	        titleLabel.setText("Goals");
    	        currentLabel.setText("Current :");
    	        currentValueLabel.setText(String.valueOf(goal.getCurrentWeight()));
    	        goalLabel.setText("Goal:");
    	        goalValueLabel.setText(String.valueOf(goal.getGoalWeight()));
    	        progressLabel.setText("Progress:");
    	        progressTextLabel.setText("Progress Percentage:");
    	        progressValueLabel.setText(String.format("%.2f%%", goal.getProgress() * 100));
    	        double progress = goal.getProgress();
    	        progressBar.setProgress(progress);
    	        
    	        // Disable add button if a goal already exists
    	        addButton.setDisable(true);
    	    } else {
    	        titleLabel.setText("Add Goal First");
    	        currentLabel.setText("");
    	        currentValueLabel.setText("");
    	        goalLabel.setText("");
    	        goalValueLabel.setText("");
    	        progressLabel.setText("");
    	        progressTextLabel.setText("");
    	        progressValueLabel.setText("");
    	        
    	        // Enable add button if no goal exists
    	        addButton.setDisable(false);
    	    }

    	    backButton.setOnAction(event -> handleBackButton());
    	    addButton.setOnAction(event -> handleAddButton());
    	    removeButton.setOnAction(event -> handleRemoveButton());
    	    updateButton.setOnAction(event -> handleUpdateButton());
    }
    private goal fetchUserGoals(String username) {
     
        return dbconnect.getInstance().getGoalByUsername(username);
    }

    private void handleBackButton() {
        System.out.println("Back button clicked");
        try {
            // Load the home.fxml file
            Parent homePage = FXMLLoader.load(getClass().getResource("/application/home.fxml"));
            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(new Scene(homePage));
            stage.setTitle("Home");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void handleAddButton() {
    	 try {
    	        // Load the add goal dialog FXML file
    	        FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/addgoal.fxml"));
    	        Parent dialogRoot = loader.load();

    	        // Get the controller associated with the dialog
    	       addgoalcontroller dialogController = loader.getController();

    	        // Create a new stage for the dialog
    	        Stage dialogStage = new Stage();
    	        dialogStage.setTitle("Add Goal");
    	        dialogStage.setScene(new Scene(dialogRoot));

    	      
    	        dialogController.setDialogStage(dialogStage);

    	     
    	        dialogStage.showAndWait();

    	        
    	        refreshGoalDetails(); 
    	    } catch (IOException e) {
    	        e.printStackTrace();
    	    }
    }

    private void handleRemoveButton() {
    	 // If there's a goal associated with the user, remove it from the database
        if (goal != null) {
            String username = session.getUser();
            dbconnect.getInstance().removeGoalForUser(username);

            // Set goal to null to indicate no goal associated with the user
            goal = null;

            // Clear UI labels
            titleLabel.setText("Add Goal First");
            currentLabel.setText("");
            currentValueLabel.setText("");
            goalLabel.setText("");
            goalValueLabel.setText("");
            progressLabel.setText("");
            progressTextLabel.setText("");
            progressValueLabel.setText("");

            // Reset progress bar
            progressBar.setProgress(0);

            // Enable add button
            addButton.setDisable(false);
        }
    }

    @FXML
    private void handleUpdateButton() {
        try {
            // Load the update goal dialog FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/updategoal.fxml"));
            Parent dialogRoot = loader.load();

            // Get the controller associated with the dialog
            updategoalcontroller dialogController = loader.getController();

            // Pass the existing goal to the update dialog
            dialogController.setExistingGoal(goal);

            // Create a new stage for the dialog
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Update Goal");
            dialogStage.setScene(new Scene(dialogRoot));

            // Set up the dialog stage
            dialogController.setDialogStage(dialogStage);

            // Show the dialog and wait for it to be closed
            dialogStage.showAndWait();

            // Refresh goal details after updating
            refreshGoalDetails();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void refreshGoalDetails() {
        String username = session.getUser();
        goal = fetchUserGoals(username);
        if (goal != null) {
            titleLabel.setText("Goals");
            currentLabel.setText("Current Weight:");
            currentValueLabel.setText(String.valueOf(goal.getCurrentWeight()));
            goalLabel.setText("Goal Weight:");
            goalValueLabel.setText(String.valueOf(goal.getGoalWeight()));
            progressLabel.setText("Progress:");
            progressTextLabel.setText("Progress Percentage:");
            progressValueLabel.setText(String.format("%.2f%%", goal.getProgress() * 100));

            
            double progress = goal.getProgress();
            progressBar.setProgress(progress);
        } else {
            titleLabel.setText("Add Goals First");
            currentLabel.setText("");
            currentValueLabel.setText("");
            goalLabel.setText("");
            goalValueLabel.setText("");
            progressLabel.setText("");
            progressTextLabel.setText("");
            progressValueLabel.setText("");

            
            progressBar.setProgress(0);
        }
    }

}
