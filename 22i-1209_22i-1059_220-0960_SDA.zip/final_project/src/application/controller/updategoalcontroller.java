package application.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import blayer.goal;
import dblayer.dbconnect; // Import the dbconnect class

public class updategoalcontroller {

    private Stage dialogStage;
    private goal existingGoal;

    @FXML
    private TextField startWeightField;

    @FXML
    private TextField goalWeightField;

    @FXML
    private TextField currentWeightField;

    @FXML
    private Button saveButton;

    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    public void setExistingGoal(goal existingGoal) {
        this.existingGoal = existingGoal;
        displayGoalDetails();
    }

    private void displayGoalDetails() {
        startWeightField.setText(String.valueOf(existingGoal.getStartWeight()));
        goalWeightField.setText(String.valueOf(existingGoal.getGoalWeight()));
        currentWeightField.setText(String.valueOf(existingGoal.getCurrentWeight()));
    }

    @FXML
    private void handleSaveButton() {
        // Update the existing goal with the new values
        existingGoal.setStartWeight(Integer.parseInt(startWeightField.getText()));
        existingGoal.setGoalWeight(Integer.parseInt(goalWeightField.getText()));
        existingGoal.setCurrentWeight(Integer.parseInt(currentWeightField.getText()));
        double progress = existingGoal.calculateProgress();
        existingGoal.setProgress(progress/ 100.0);
        // Save the updated goal to the database
        dbconnect.getInstance().updateGoal(existingGoal);

        // Close the dialog
        dialogStage.close();
    }
}
