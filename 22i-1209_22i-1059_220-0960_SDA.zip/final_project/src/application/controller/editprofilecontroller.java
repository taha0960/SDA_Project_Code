package application.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import dblayer.dbconnect;
import blayer.User;

import java.util.Arrays;

public class editprofilecontroller {

    @FXML private TextField usernameField;
    @FXML private TextField passwordField;
    @FXML private TextField nameField;
    @FXML private TextField ageField;
    @FXML private TextField heightField;
    @FXML private TextField weightField;
    @FXML private TextField activityLevelField;
    @FXML private TextField dietaryPreferencesField;
    @FXML private TextField allergiesField;
    @FXML private Button submitButton;
    private Stage dialogStage;
    private User user;

    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    public void setUser(User user) {
        this.user = user;
        // Populate fields with current user data
        if (user != null) {
            usernameField.setText(user.getUsername());
            passwordField.setText(user.getPassword());
            nameField.setText(user.getName());
            ageField.setText(String.valueOf(user.getAge()));
            heightField.setText(String.valueOf(user.getHeight()));
            weightField.setText(String.valueOf(user.getWeight()));
            activityLevelField.setText(String.valueOf(user.getActivityLevel()));
            dietaryPreferencesField.setText(String.join("\n", user.getDietaryPreferences()));
            allergiesField.setText(String.join("\n", user.getAllergies()));
        }
    }

    @FXML
    private void handleSubmitButton() {
        // Update user data
        if (user != null) {
            try {
                user.setUsername(usernameField.getText());
                user.setPassword(passwordField.getText());
                user.setName(nameField.getText());
                user.setAge(Integer.parseInt(ageField.getText()));
                user.setHeight(Double.parseDouble(heightField.getText()));
                user.setWeight(Double.parseDouble(weightField.getText()));
                user.setActivityLevel(Integer.parseInt(activityLevelField.getText()));
                // Assuming dietaryPreferences and allergies are comma-separated strings
                user.setDietaryPreferences(Arrays.asList(dietaryPreferencesField.getText().split("\n")));
                user.setAllergies(Arrays.asList(allergiesField.getText().split("\n")));

                // Update the user data in the database
                dbconnect.getInstance().updateUser(user);

                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Update Successful");
                alert.setHeaderText(null);
                alert.setContentText("Profile updated successfully!");

                // Close the dialog after user closes the alert
                alert.setOnHidden(evt -> dialogStage.close());
                alert.showAndWait();
            } catch (NumberFormatException e) {
                // Handle any number format exceptions if the input is invalid
                Alert alert = new Alert(AlertType.ERROR);
                alert.setTitle("Update Failed");
                alert.setHeaderText("Invalid input");
                alert.setContentText("Please enter valid data.");
                alert.showAndWait();
            }
        }
    }
}
