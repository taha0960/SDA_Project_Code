package application.controller;

import java.io.IOException;
import java.util.List;
import java.io.ByteArrayInputStream;
import blayer.resource;
import blayer.healthpal;
import blayer.fitnesslibrary;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Cursor;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class resourcecontroller {

    @FXML
    private VBox categoriesVBox;

    @FXML
    private Button backbutton;

    @FXML
    private ImageView imageView1;

    private String categoryName;

    @FXML
    public void initialize() {
        backbutton.setOnAction(event -> handleBackButtonClick());
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
        populateResources();
    }

    private void populateResources() {
        healthpal healthPal = healthpal.getInstance();
        fitnesslibrary fitnessLibrary = healthPal.getFitnessLibrary();
        
        // Get the resources for the selected category
        List<resource> resources = fitnessLibrary.getResourcesByCategory(categoryName);

        // Clear any existing children
        categoriesVBox.getChildren().clear();

        // Populate the VBox with resources
        for (resource res : resources) {
            addResource(res);
        }
    }

    private void addResource(resource res) {
        // Label for the title
        Label title = new Label(res.getTitle());
        title.setStyle("-fx-font-weight: bold; -fx-padding: 5;");

        // Hyperlink for the content
        Hyperlink contentLink = new Hyperlink(res.getContent());
        contentLink.setWrapText(true);
        contentLink.setStyle("-fx-padding: 5;");
        contentLink.setCursor(Cursor.HAND);
        contentLink.setOnAction(event -> {
            // Open the resource's link when clicked (if it exists)
            String resourceLink = res.getLink();
            if (resourceLink != null && !resourceLink.isEmpty()) {
                try {
                    java.awt.Desktop.getDesktop().browse(java.net.URI.create(resourceLink));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        // ImageView for the image
        ImageView imageView = new ImageView();
        if (res.getImage() != null && res.getImage().length > 0) {
            Image image = new Image(new ByteArrayInputStream(res.getImage()));
            imageView.setImage(image);
            imageView.setFitHeight(200); // Set a larger height for the image
            imageView.setPreserveRatio(true);
        }

        // VBox to hold the title, content, and image
        VBox resourceBox = new VBox(imageView, title, contentLink);
        resourceBox.setAlignment(javafx.geometry.Pos.CENTER); // Center align content
        resourceBox.setStyle("-fx-border-color: #FFFFFF; -fx-padding: 10; -fx-spacing: 5; -fx-background-radius: 5;");
        resourceBox.setPrefWidth(276.0);
        resourceBox.setPrefHeight(400); // Adjust the height of the VBox

        // Add the VBox to the categoriesVBox
        categoriesVBox.getChildren().add(resourceBox);
    }

    private void handleBackButtonClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/fitnessLibrary.fxml"));
            Parent fitnessLibraryRoot = loader.load();

            Stage stage = (Stage) backbutton.getScene().getWindow();
            Scene fitnessLibraryScene = new Scene(fitnessLibraryRoot);
            stage.setScene(fitnessLibraryScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
