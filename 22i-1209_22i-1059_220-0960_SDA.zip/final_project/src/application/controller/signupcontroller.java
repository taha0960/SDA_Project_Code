package application.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import dblayer.dbconnect;

import java.io.IOException;
import java.util.Arrays;

import blayer.User;

public class signupcontroller {

    @FXML
    private TextField nameField;

    @FXML
    private TextField passwordField;

    @FXML
    private TextField weightField;

    @FXML
    private TextField heightField;

    @FXML
    private TextField ageField;

    @FXML
    private TextField usernameField;

    @FXML
    private ChoiceBox<String> activityLevelChoiceBox;

    @FXML
    private TextArea dietaryPreferencesField;

    @FXML
    private TextArea allergiesField;

    @FXML
    private Button signupButton;

    @FXML
    private void initialize() {
        // Initialize the choice box with activity levels
        activityLevelChoiceBox.getItems().addAll("1", "2", "3", "4", "5");
        activityLevelChoiceBox.setValue("1");

        // Add event handler for the signup button
        signupButton.setOnAction(event -> handlesignupButtonAction());
    }

    private void handlesignupButtonAction() {
    	String name = nameField.getText().trim();
        String password = passwordField.getText().trim();
        String weightText = weightField.getText().trim();
        String heightText = heightField.getText().trim();
        String ageText = ageField.getText().trim();
        String username = usernameField.getText().trim();
        int activityLevel = Integer.parseInt(activityLevelChoiceBox.getValue());
        String[] dietaryPreferences = dietaryPreferencesField.getText().split("\n");
        String[] allergies = allergiesField.getText().split("\n");

        // Check if any of the required fields are empty
        if (name.isEmpty() || password.isEmpty() || weightText.isEmpty() || heightText.isEmpty() || ageText.isEmpty() || username.isEmpty()) {
            showAlert("Missing Fields", "Please fill in all required fields.");
            return; // Exit the method if any required field is empty
        }

        // Parse numerical values
        double weight;
        double height;
        int age;
        try {
            weight = Double.parseDouble(weightText);
            height = Double.parseDouble(heightText);
            age = Integer.parseInt(ageText);
        } catch (NumberFormatException e) {
            showAlert("Invalid Input", "Please enter valid numerical values for weight, height, and age.");
            return; // Exit the method if any numerical input is invalid
        }

        
        // Create a new User instance
        User user = new User(username, password, name, age, height, weight, activityLevel, Arrays.asList(dietaryPreferences), Arrays.asList(allergies));
        dbconnect.getInstance().addUser(user);
       
        showAlert2("User Added", "The user has been successfully added to the database.");
        
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/application/scene.fxml"));
            Stage stage = (Stage) signupButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    private void showAlert2(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
