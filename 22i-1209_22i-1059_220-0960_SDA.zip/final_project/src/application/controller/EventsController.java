package application.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import java.util.Optional;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.stream.Collectors;

import blayer.Event;

public class EventsController {

    @FXML
    private ComboBox<String> categoryComboBox;

    @FXML
    private ComboBox<String> dateComboBox;

    @FXML
    private ComboBox<String> difficultyComboBox;

    @FXML
    private ListView<Event> eventsListView;

    @FXML
    private TextField nameField;

    @FXML
    private TextField placeField;

    @FXML
    private TextField descriptionField;

    @FXML
    private TextField priceField;

    @FXML
    private TextField dateField;

    @FXML
    private ComboBox<String> newCategoryComboBox;

    @FXML
    private ComboBox<String> newDifficultyComboBox;

    private ObservableList<Event> events;

    @FXML
    private Button registerbutton;

    @FXML
    private Button backbutton;

    @FXML
    private void initialize() {
        // Initialize the ComboBox items
        categoryComboBox.setItems(FXCollections.observableArrayList("Running", "Yoga", "HIIT"));
        dateComboBox.setItems(FXCollections.observableArrayList("Today", "This Week", "This Month"));
        difficultyComboBox.setItems(FXCollections.observableArrayList("Easy", "Medium", "Hard"));
        newCategoryComboBox.setItems(FXCollections.observableArrayList("Running", "Yoga", "HIIT"));
        newDifficultyComboBox.setItems(FXCollections.observableArrayList("Easy", "Medium", "Hard"));

        events = FXCollections.observableArrayList(
                new Event("5K Charity Run", "Downtown", "Free", "Running", LocalDate.now(), "Easy"),
                new Event("Sunset Yoga", "Beachside", "$10", "Yoga", LocalDate.now().plusDays(1), "Medium"),
                new Event("HIIT Bootcamp", "Central Park", "$20", "HIIT", LocalDate.now().plusDays(2), "Hard")
        );

        // Display all events initially
        eventsListView.setItems(events);

        // Add listeners to ComboBoxes to filter events
        categoryComboBox.setOnAction(event -> filterEvents());
        dateComboBox.setOnAction(event -> filterEvents());
        difficultyComboBox.setOnAction(event -> filterEvents());

        backbutton.setOnAction(event -> handleBackButton());
    }

    @FXML
    private void handleBackButton() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/home.fxml"));
            Parent homePage = loader.load();
            Stage stage = (Stage) backbutton.getScene().getWindow();
            stage.setScene(new Scene(homePage));
            stage.setTitle("Home");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void filterEvents() {
        String selectedCategory = categoryComboBox.getValue();
        String selectedDate = dateComboBox.getValue();
        String selectedDifficulty = difficultyComboBox.getValue();

        List<Event> filteredEvents = events.stream()
                .filter(event -> (selectedCategory == null || event.getCategory().equals(selectedCategory)))
                .filter(event -> {
                    if (selectedDate == null) return true;
                    LocalDate eventDate = event.getDate();
                    LocalDate now = LocalDate.now();
                    switch (selectedDate) {
                        case "Today":
                            return eventDate.isEqual(now);
                        case "This Week":
                            return !eventDate.isBefore(now) && eventDate.isBefore(now.plusWeeks(1));
                        case "This Month":
                            return !eventDate.isBefore(now) && eventDate.isBefore(now.plusMonths(1));
                        default:
                            return true;
                    }
                })
                .filter(event -> (selectedDifficulty == null || event.getDifficulty().equals(selectedDifficulty)))
                .collect(Collectors.toList());

        eventsListView.setItems(FXCollections.observableArrayList(filteredEvents));
    }

    @FXML
    public void registerForEvent() {
        Event selectedEvent = eventsListView.getSelectionModel().getSelectedItem();
        if (selectedEvent != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Event Registration");
            alert.setHeaderText("Register for Event");
            alert.setContentText("Do you want to register for the event: " + selectedEvent.getName() + "?");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                // Remove the event from the list after registration
                events.remove(selectedEvent);
                filterEvents();

                // Display confirmation message
                Alert confirmation = new Alert(Alert.AlertType.INFORMATION);
                confirmation.setTitle("Registration Confirmation");
                confirmation.setHeaderText(null);
                confirmation.setContentText("You have successfully registered for the event: " + selectedEvent.getName());
                confirmation.showAndWait();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("No Event Selected");
            alert.setHeaderText(null);
            alert.setContentText("Please select an event to register.");
            alert.showAndWait();
        }
    }

    @FXML
    private void addEvent() {
        try {
            String name = nameField.getText().trim();
            String place = placeField.getText().trim();
            String description = descriptionField.getText().trim();
            String price = priceField.getText().trim();
            LocalDate date = LocalDate.parse(dateField.getText().trim());
            String category = newCategoryComboBox.getValue();
            String difficulty = newDifficultyComboBox.getValue();

            if (name.isEmpty() || place.isEmpty() || description.isEmpty() || price.isEmpty() || category == null || difficulty == null) {
                showAlert(Alert.AlertType.WARNING, "Incomplete Fields", "Please fill out all fields.");
                return;
            }

            Event newEvent = new Event(name, place, price, category, date, difficulty);
            events.add(newEvent);
            filterEvents();

            // Clear the input fields
            nameField.clear();
            placeField.clear();
            descriptionField.clear();
            priceField.clear();
            dateField.clear();
            newCategoryComboBox.setValue(null);
            newDifficultyComboBox.setValue(null);

        } catch (DateTimeParseException e) {
            showAlert(Alert.AlertType.ERROR, "Invalid Date Format", "Please enter the date in the format yyyy-mm-dd.");
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
