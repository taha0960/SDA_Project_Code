package application.controller;

import javafx.fxml.FXML;
import dblayer.dbconnect;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import blayer.session;
import java.io.IOException;
import blayer.User;
import blayer.healthpal;
public class logincontroller {

    @FXML
    private ImageView imageView1;

    @FXML
    private TextField usernameField;

    @FXML
    private TextField passwordField;

    @FXML
    private Label statusLabel;

    @FXML
    private Button loginButton;
    
    public User user;
    
    @FXML
    private Button newacc;

    @FXML
    public void initialize() {
        // Initialize any required logic here
        loginButton.setOnAction(event -> handleLoginButtonClick());
        newacc.setOnAction(event -> handlenewaccClick());
    }

    private void handlenewaccClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/signup.fxml"));
            Parent signupRoot = loader.load();

            // Get the signup controller
            signupcontroller signupController = loader.getController();

            Stage currentStage = (Stage) loginButton.getScene().getWindow();
            Scene signupScene = new Scene(signupRoot);
            currentStage.setScene(signupScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void handleLoginButtonClick() {
        String username = usernameField.getText();
        String password = passwordField.getText();

     // Call the method to check if the login is successful
        boolean loginSuccessful = dbconnect.getInstance().loginUser(username, password);

        if (loginSuccessful) {
        	  user = dbconnect.getInstance().getUserByUsername(username);
             
             // Set the user in the session
             session.setUser(user.getUsername());
             healthpal healthPal = healthpal.getInstance();
        	 
            try {
            	  FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/home.fxml"));
                  Parent homeRoot = loader.load();
                  
                  // Get the home controller and set the user
                  homecontroller homeController = loader.getController();
                  homeController.setUser(user);

                  Stage currentStage = (Stage) loginButton.getScene().getWindow();
                  Scene homeScene = new Scene(homeRoot);
                  currentStage.setScene(homeScene);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            // If login is unsuccessful, display an error dialog
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Login Error");
            alert.setHeaderText(null);
            alert.setContentText("Incorrect username or password. Please try again.");
            alert.showAndWait();
        }
        }
}
