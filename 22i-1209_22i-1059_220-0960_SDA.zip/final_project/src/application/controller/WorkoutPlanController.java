package application.controller;

import java.io.IOException;

import blayer.Trainer;
import blayer.User;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import javafx.event.ActionEvent;

public class WorkoutPlanController {
    @FXML
    private ListView<String> workoutPlanListView;
    @FXML
    private Button selectWorkoutPlanButton;
    @FXML
    private Label workoutInstructionsLabel;
    @FXML
    private Label postWorkoutPlanLabel;

    private User user;
    private Trainer trainer;

    @FXML
    private Button backButton;

    @FXML
    private void initialize() {
        // Initialize workout plans based on time of the day
        workoutPlanListView.getItems().addAll("Plan A(Morning)", "Plan B(Evening)", "Plan C(Night)");
    }

    @FXML
    private void handleSelectWorkoutPlanButtonAction(ActionEvent event) {
        String selectedPlan = workoutPlanListView.getSelectionModel().getSelectedItem();
        if (selectedPlan != null) {
            switch (selectedPlan) {
                case "Plan A(Morning)":
                    workoutInstructionsLabel.setText("Plan A Instructions: Warm-up with cardio for 10 minutes, Strength training for 30 minutes, Cool down with stretching.");
                    postWorkoutPlanLabel.setText("Post-workout plan for Plan A: Stretch for 10 minutes, drink protein shake.");
                    break;
                case "Plan B(Evening)":
                    workoutInstructionsLabel.setText("Plan B Instructions: Warm-up with dynamic stretches for 5 minutes, HIIT workout for 20 minutes, Cool down with yoga.");
                    postWorkoutPlanLabel.setText("Post-workout plan for Plan B: Foam roll for 5 minutes, have a balanced meal.");
                    break;
                case "Plan C(Night)":
                    workoutInstructionsLabel.setText("Plan C Instructions: Warm-up with light jogging for 15 minutes, Endurance training for 40 minutes, Cool down with foam rolling.");
                    postWorkoutPlanLabel.setText("Post-workout plan for Plan C: Take a cold shower, replenish electrolytes.");
                    break;
            }
        }
               }

    @FXML
    private void handleBackButtonAction(ActionEvent event) {
        try {
            // Load home.fxml
            Parent homeRoot = FXMLLoader.load(getClass().getResource("/application/home.fxml"));
            Scene homeScene = new Scene(homeRoot);

            // Get the current stage
            Stage currentStage = (Stage) backButton.getScene().getWindow();

            // Set the new scene
            currentStage.setScene(homeScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setTrainer(Trainer trainer) {
        this.trainer = trainer;
    }
}
