package application.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import blayer.goal;
import blayer.session;
import dblayer.dbconnect;

public class addgoalcontroller {
    private Stage dialogStage;

    @FXML
    private TextField startWeightField;

    @FXML
    private TextField goalWeightField;

    @FXML
    private TextField currentWeightField; // Added TextField for current weight

    @FXML
    private Button addButton;

    @FXML
    private Button cancelButton;

    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    @FXML
    private void handleAddButton() {
        // Get user input from text fields
        int startWeight = Integer.parseInt(startWeightField.getText());
        int goalWeight = Integer.parseInt(goalWeightField.getText());
        int currentWeight = Integer.parseInt(currentWeightField.getText());
        String username = session.getUser();
        
        // Create a new goal object with the input data
        goal newGoal = new goal(startWeight, goalWeight, currentWeight, 0.0, username);

        double progress = newGoal.calculateProgress();
        System.out.println(progress);
        newGoal.setProgress(progress/ 100.0);
        
        // Save the new goal to the database
        saveGoalToDatabase(newGoal);

        // Close the dialog
        dialogStage.close();
    }

    @FXML
    private void handleCancelButton() {
        // Close the dialog without saving
        dialogStage.close();
    }

    private void saveGoalToDatabase(goal newGoal) {
        // Save the goal to the database along with the current user in the session
        String username = session.getUser();
        dbconnect.getInstance().addGoalForUser(username, newGoal);
    }
    
 
}
