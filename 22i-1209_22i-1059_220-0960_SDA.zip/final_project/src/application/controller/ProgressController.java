package application.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ProgressController {

    @FXML
    private Label goalsSummaryLabel;

    @FXML
    private Label personalRecordsLabel;

    @FXML
    private Label goalStatusLabel;

    @FXML
    private TextField newGoalField; // Text field for entering new goals

    // List to store user-set goals
    private List<String> userGoals = new ArrayList<>();

    @FXML
    private void initialize() {
        // Clear all labels initially
        clearLabels();

        // Fetch and display the user's personal records
        personalRecordsLabel.setText("Personal Records: Bench Press - 200 lbs, Running - 5K in 25 minutes");

        // Fetch and display the user's goal status
        goalStatusLabel.setText("Goal Status: On track");
    }

    private void clearLabels() {
        // Clear all goal labels
        goalsSummaryLabel.setText("");
    }

    private void updateGoalsSummary() {
        // Construct the string for displaying user-set goals
        StringBuilder goalsText = new StringBuilder("Active Goals:");
        for (String goal : userGoals) {
            goalsText.append(" ").append(goal).append(",");
        }
        // Remove the trailing comma
        if (!userGoals.isEmpty()) {
            goalsText.deleteCharAt(goalsText.length() - 1);
        }

        // Set the goals summary label with the constructed string
        goalsSummaryLabel.setText(goalsText.toString());
    }

    @FXML
    private void addGoal() {
        String newGoal = newGoalField.getText().trim();
        if (!newGoal.isEmpty()) {
            // Add the new goal to the list of user goals
            userGoals.add(newGoal);

            // Update the UI to reflect the new goal
            updateGoalsSummary();

            // Clear the input field
            newGoalField.clear();
        }
    }

    @FXML
    private void goBack() {
        try {
            // Load home.fxml
            Parent homeRoot = FXMLLoader.load(getClass().getResource("/application/home.fxml"));
            Scene homeScene = new Scene(homeRoot);

            // Get the current stage
            Stage currentStage = (Stage) newGoalField.getScene().getWindow();

            // Set the new scene
            currentStage.setScene(homeScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
