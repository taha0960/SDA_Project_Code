package application.controller;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import blayer.Nutritionist;
import blayer.MealPlan;
import blayer.TimeSlot;
import blayer.User;

public class MealPlanController {

    @FXML
    private ComboBox<String> dietaryGoalsCombo;

    @FXML
    private ComboBox<String> preferencesCombo;

    @FXML
    private TextField allergiesField;

    @FXML
    private Button generatePlanButton;

    @FXML
    private Button backButton;

    @FXML
    private Label resultLabel;

    @FXML
    public void initialize() {
        dietaryGoalsCombo.setItems(FXCollections.observableArrayList("Weight Loss", "Muscle Gain"));
        preferencesCombo.setItems(FXCollections.observableArrayList("Vegetarian", "Low-Carb"));
    }

   
    
    @FXML
    private void generateMealPlan() {
        String dietaryGoal = dietaryGoalsCombo.getValue();
        String preference = preferencesCombo.getValue();
        String allergies = allergiesField.getText();

        if (dietaryGoal == null || preference == null || allergies.isEmpty()) {
            resultLabel.setText("Please fill all the fields.");
        } else {
          
            String userName = "jalal";

            // Creating a dummy Nutritionist for demonstration purposes
            List<TimeSlot> availability = new ArrayList<>();
            Nutritionist nutritionist = new Nutritionist("ahad", "Experienced nutritionist", "General", availability);

            // Creating a meal plan based on the user input
            MealPlan mealPlan = nutritionist.createMealPlan(userName);

            // Displaying the meal plan
            StringBuilder mealPlanDisplay = new StringBuilder();
            mealPlanDisplay.append("Meal Plan generated based on your input:\n");
            mealPlanDisplay.append("Breakfast: ").append(String.join(", ", mealPlan.getBreakfast())).append("\n");
            mealPlanDisplay.append("Lunch: ").append(String.join(", ", mealPlan.getLunch())).append("\n");
            mealPlanDisplay.append("Dinner: ").append(String.join(", ", mealPlan.getDinner())).append("\n");
            mealPlanDisplay.append("Snacks: ").append(String.join(", ", mealPlan.getSnacks())).append("\n");

            resultLabel.setText(mealPlanDisplay.toString());
        }
    }



    @FXML
    private void goBack() {
        try {
            Stage stage = (Stage) resultLabel.getScene().getWindow();
            Parent root = FXMLLoader.load(getClass().getResource("/application/home.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
