package application.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class SleepController {
    private static final double RECOMMENDED_SLEEP_DURATION = 8.0; // hours

    @FXML
    private TextField sleepDurationField;

    @FXML
    private Label sleepQualityLabel;

    @FXML
    private Label sleepEfficiencyLabel;

    @FXML
    private Label motivationalMessageLabel;

    @FXML
    private Label titleLabel;  // fx:id for the title label

    @FXML
    private Label sleepDurationLabel;  // fx:id for the sleep duration label

    @FXML
    private Label sleepQualityTitleLabel;  // fx:id for the sleep quality title label

    @FXML
    private Label sleepEfficiencyTitleLabel;  // fx:id for the sleep efficiency title label

    @FXML
    private Button evaluateSleepButton;  // fx:id for the evaluate sleep button

    @FXML
    private Button backButton; // fx:id for the back button

    @FXML
    private void evaluateSleep() {
        double sleepDuration;
        try {
            sleepDuration = Double.parseDouble(sleepDurationField.getText());
        } catch (NumberFormatException e) {
            sleepQualityLabel.setText("Invalid input");
            sleepEfficiencyLabel.setText("");
            motivationalMessageLabel.setText("");
            return;
        }

        if (sleepDuration > 10.0) {
            sleepQualityLabel.setText("Too Much Sleep");
            sleepEfficiencyLabel.setText("");
            motivationalMessageLabel.setText("Too much sleep can be harmful to your health. Try to maintain a balanced sleep schedule.");
        } else {
            double sleepEfficiency = calculateSleepEfficiency(sleepDuration);
            sleepEfficiencyLabel.setText(String.format("%.2f%%", sleepEfficiency));

            if (sleepDuration < RECOMMENDED_SLEEP_DURATION) {
                sleepQualityLabel.setText("Bad Sleep");
                motivationalMessageLabel.setText("You need more sleep for better health and productivity. Try to go to bed earlier tonight.");
            } else {
                sleepQualityLabel.setText("Good Sleep");
                motivationalMessageLabel.setText("Great job! Keep up the good sleep habits.");
            }
        }
    }

    private double calculateSleepEfficiency(double sleepDuration) {
        // Example calculation: Sleep efficiency = (actual sleep duration / total time spent in bed) * 100%
        // For simplicity, let's assume total time spent in bed is 8 hours
        double totalTimeInBed = 8.0; // hours
        double calculatedEfficiency = (sleepDuration / totalTimeInBed) * 100.0;

        // Ensure sleep efficiency does not exceed 100%
        return Math.min(calculatedEfficiency, 100.0);
    }

    @FXML
    private void handleBackButtonAction() {
        try {
            // Load home.fxml
            Parent homeRoot = FXMLLoader.load(getClass().getResource("/application/home.fxml"));
            Scene homeScene = new Scene(homeRoot);

            // Get the current stage
            Stage currentStage = (Stage) backButton.getScene().getWindow();

            // Set the new scene
            currentStage.setScene(homeScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
