package application.controller;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import blayer.fitnesslibrary;
import blayer.healthpal;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class fitnesscontroller {

    @FXML
    private VBox categoriesVBox;

    @FXML
    private TextField search;

    @FXML
    private Button backbutton;
    
    private List<String> categories;

    @FXML
    public void initialize() {
    	
        healthpal healthPal = healthpal.getInstance();
        
        if (healthPal.getFitnessLibrary() == null) {
            healthPal.createFitnessLibrary();
        }
        
        fitnesslibrary fitnessLibrary = healthPal.getFitnessLibrary();

        // Get the list of categories from fitnessLibrary
        categories = fitnessLibrary.getCategories();

        // Populate the VBox with categories
        populateCategories(categories);

        // Add listener to the search TextField
        search.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                filterCategories(newValue);
            }
        });

        backbutton.setOnAction(event -> handleBackButtonAction());
    }

    private void populateCategories(List<String> categories) {
        categoriesVBox.getChildren().clear();
        for (String categoryName : categories) {
            addCategoryButton(categoryName);
        }
    }

    private void addCategoryButton(String categoryName) {
        Button button = new Button(categoryName);
        button.setAlignment(javafx.geometry.Pos.CENTER);
        button.setPrefHeight(18.0);
        button.setPrefWidth(262.0);
        button.setStyle("-fx-background-color: #00A8CF; -fx-background-radius: 5; -fx-text-fill: #FFFFFF; -fx-padding: 5;");

        // Set an action handler for the button
        button.setOnAction(event -> handleCategoryButtonClick(categoryName));

        categoriesVBox.getChildren().add(button);
    }

    private void handleCategoryButtonClick(String categoryName) {
        try {
            // Load resource.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/resource.fxml"));
            Parent resourceRoot = loader.load();

            // Get the resource controller and set the category name
            resourcecontroller resourceController = loader.getController();
            resourceController.setCategoryName(categoryName);

            // Switch to the resource scene
            Stage stage = (Stage) categoriesVBox.getScene().getWindow();
            Scene resourceScene = new Scene(resourceRoot);
            stage.setScene(resourceScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void filterCategories(String searchText) {
        List<String> filteredCategories = categories.stream()
                .filter(category -> category.toLowerCase().contains(searchText.toLowerCase()))
                .collect(Collectors.toList());
        populateCategories(filteredCategories);
    }
    
    @FXML
    private void handleBackButtonAction() {
        try {
            // Load the home.fxml file
            Parent homePage = FXMLLoader.load(getClass().getResource("/application/home.fxml"));

            // Get the current stage (window)
            Stage stage = (Stage) backbutton.getScene().getWindow();

            // Set the scene to homePage
            stage.setScene(new Scene(homePage));

            // Optional: Set the title of the window
            stage.setTitle("Home");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
