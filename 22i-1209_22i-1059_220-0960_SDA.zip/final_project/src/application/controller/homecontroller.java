package application.controller;

import blayer.User;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.event.ActionEvent;




import java.io.IOException;

public class homecontroller {

    @FXML
    private ImageView imageView1;

    @FXML
    private Button button1;

    @FXML
    private ImageView imageView2;

    @FXML
    private Button fitnessLibraryButton;

    @FXML
    private Button hydrationLevelButton;

    @FXML
    private Label calorieFunctionalityLabel;

    @FXML
    private Button workoutRoutineButton;

    @FXML
    private Label bottomLabel;

    @FXML
    private Button bottomButton;

    @FXML
    private Label goalsLabel;

    @FXML
    private Button mealPlanButton;
    
    @FXML
    private Button eventButton;

    private User user;
    
    @FXML
    private Button sleepButton;

    @FXML
    private Button progressButton;

    @FXML
    public void initialize() {
        fitnessLibraryButton.setOnAction(event -> handleFitnessLibraryButtonClick());
        hydrationLevelButton.setOnAction(event -> handleHydrationLevelButtonClick());
        button1.setOnAction(event -> handleProfileButtonClick());
        bottomButton.setOnAction(event -> handleBottomButtonClick());
        workoutRoutineButton.setOnAction(this::handleWorkoutRoutineButtonAction);
        mealPlanButton.setOnAction(event -> handleMealPlanButtonClick(event));
        eventButton.setOnAction(event -> handleEventButtonClick(event));
        sleepButton.setOnAction(event -> handleSleepButtonClick(event));
        progressButton.setOnAction(event -> handleProgressButtonClick(event));
    }
    
    @FXML
    private void handleEventButtonClick(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/events-view.fxml"));
            Parent eventsViewPage = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(eventsViewPage));
            stage.setTitle("Events View");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void handleFitnessLibraryButtonClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/fitnessLibrary.fxml"));
            Parent fitnessPage = loader.load();
            Stage stage = (Stage) fitnessLibraryButton.getScene().getWindow();
            stage.setScene(new Scene(fitnessPage));
            stage.setTitle("Fitness Library");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleHydrationLevelButtonClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/hydrationlevel.fxml"));
            Parent hydrationPage = loader.load();
            Stage stage = (Stage) hydrationLevelButton.getScene().getWindow();
            stage.setScene(new Scene(hydrationPage));
            stage.setTitle("Hydration Level");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleWorkoutRoutineButtonAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/workoutplan.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) workoutRoutineButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Workout Routine");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleProfileButtonClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/profile.fxml"));
            Parent profileRoot = loader.load();
            profilecontroller profileController = loader.getController();
            profileController.setUser(user);
            Stage currentStage = (Stage) button1.getScene().getWindow();
            currentStage.setScene(new Scene(profileRoot));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleBottomButtonClick() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/goal.fxml"));
            Parent goalRoot = loader.load();
            Stage currentStage = (Stage) bottomButton.getScene().getWindow();
            currentStage.setScene(new Scene(goalRoot));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleMealPlanButtonClick(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/mealplan.fxml"));
            Parent mealPlanPage = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(mealPlanPage));
            stage.setTitle("Meal Plan");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void setUser(User user) {
        this.user = user;
    }
    
    @FXML
    private void handleSleepButtonClick(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/sleep-view.fxml"));
            Parent sleepViewPage = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(sleepViewPage));
            stage.setTitle("Sleep View");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleProgressButtonClick(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/progress-view.fxml"));
            Parent progressViewPage = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(progressViewPage));
            stage.setTitle("Progress View");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
