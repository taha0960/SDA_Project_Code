package application.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import dblayer.dbconnect;
import java.io.IOException;
import blayer.User;
import blayer.session;

public class profilecontroller {

    @FXML
    private ImageView imageView2;

    @FXML
    private Label userProfileLabel;

    @FXML
    private Label usernameTextLabel;

    @FXML
    private Label usernameLabel;

    @FXML
    private Label passwordTextLabel;

    @FXML
    private Label passwordLabel;

    @FXML
    private Label nameTextLabel;

    @FXML
    private Label nameLabel;

    @FXML
    private Label ageTextLabel;

    @FXML
    private Label ageLabel;

    @FXML
    private Label heightTextLabel;

    @FXML
    private Label heightLabel;

    @FXML
    private Label weightTextLabel;

    @FXML
    private Label weightLabel;

    @FXML
    private Label activityLevelTextLabel;

    @FXML
    private Label activityLevelLabel;

    @FXML
    private Label dietaryPreferencesTextLabel;

    @FXML
    private Label dietaryPreferencesLabel;

    @FXML
    private Label allergiesTextLabel;

    @FXML
    private Label allergiesLabel;

    @FXML
    private Button edit;

    @FXML
    private Button backbutton;

    @FXML
    private Button signOutButton;

    @FXML
    private Button deleteAccountButton;

    private User user; // Add User field

    @FXML
    public void initialize() {
        // Fetch user details and display them
        displayUserDetails();

        backbutton.setOnAction(event -> {
            try {
                // Load the home.fxml file
                Parent homePage = FXMLLoader.load(getClass().getResource("/application/home.fxml"));

                // Get the current stage (window)
                Stage stage = (Stage) backbutton.getScene().getWindow();

                // Set the scene to homePage
                stage.setScene(new Scene(homePage));

                // Optional: Set the title of the window
                stage.setTitle("Home");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        edit.setOnAction(event -> handleEditButton());
        signOutButton.setOnAction(event -> handleSignOutButton());
        deleteAccountButton.setOnAction(event -> handleDeleteAccountButton());
    }

    private void handleEditButton() {
        try {
            // Load the edit_profile.fxml file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/updateprofile.fxml"));
            Parent editProfilePage = loader.load();

            // Get the controller associated with the edit_profile.fxml
            editprofilecontroller editProfileController = loader.getController();

            // Pass the current user details to the edit profile controller
            editProfileController.setUser(user);

            // Create a new stage for the edit profile dialog
            Stage editProfileStage = new Stage();
            editProfileStage.setTitle("Edit Profile");
            editProfileStage.setScene(new Scene(editProfilePage));

            // Pass the dialog stage to the edit profile controller
            editProfileController.setDialogStage(editProfileStage);

            // Show the edit profile dialog
            editProfileStage.showAndWait();

            // After the dialog is closed, refresh the user details in the profile view
            displayUserDetails();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

   
    	private void handleSignOutButton() {
    	    try {
    	        
    	        session.removeUser();

    	        
    	        Parent sceneRoot = FXMLLoader.load(getClass().getResource("/application/scene.fxml"));

    	       
    	        Stage currentStage = (Stage) signOutButton.getScene().getWindow();

    	       
    	        Scene sceneScene = new Scene(sceneRoot);

    	        
    	        currentStage.setScene(sceneScene);
    	    } catch (IOException e) {
    	        e.printStackTrace();
    	    }
    	}
  

    	private void handleDeleteAccountButton() {
    	    
    	    String username = session.getUser();

    	    
    	    dbconnect.getInstance().deleteUser(username);

    	  
    	    session.removeUser();

    	    try {
    	        
    	        Parent sceneRoot = FXMLLoader.load(getClass().getResource("/application/scene.fxml"));

    	       
    	        Stage currentStage = (Stage) deleteAccountButton.getScene().getWindow();

    	      
    	        Scene sceneScene = new Scene(sceneRoot);
    	        currentStage.setScene(sceneScene);
    	    } catch (IOException e) {
    	        e.printStackTrace();
    	    }
    	}
    	
    private void displayUserDetails() {
       
        String username = session.getUser();

       
        user = fetchUserDetails(username);

      
        if (user != null) {
            usernameLabel.setText(user.getUsername());
            passwordLabel.setText(user.getPassword());
            nameLabel.setText(user.getName());
            ageLabel.setText(String.valueOf(user.getAge()));
            heightLabel.setText(String.valueOf(user.getHeight()));
            weightLabel.setText(String.valueOf(user.getWeight()));
            activityLevelLabel.setText(String.valueOf(user.getActivityLevel()));
            dietaryPreferencesLabel.setText(String.join("\n", user.getDietaryPreferences()));
            allergiesLabel.setText(String.join("\n", user.getAllergies()));
        }
    }

    public void setUser(User user) {
        this.user = user;
    }

    private User fetchUserDetails(String username) {
        // Fetch user details from the database based on the username
        return dbconnect.getInstance().getUserByUsername(username);
    }
}
