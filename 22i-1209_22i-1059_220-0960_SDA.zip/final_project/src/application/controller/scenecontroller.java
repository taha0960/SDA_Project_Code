package application.controller;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class scenecontroller {

    @FXML
    private ImageView imageView1;

    @FXML
    private ImageView imageView2;

    @FXML
    private Label label;

    @FXML
    public Button sign;

    @FXML
    public  Button login;

    @FXML
    public void initialize() {
    	login.setOnAction(this::handleLoginButtonClick);
    	sign.setOnAction(this::handlesignupButtonClick);
    }

    private void handleLoginButtonClick(ActionEvent event) {
        try {
            // Load the new FXML file
            Parent loginRoot = FXMLLoader.load(getClass().getResource("/application/login.fxml"));

            // Get the current stage
            Stage currentStage = (Stage) login.getScene().getWindow();

            // Create a new scene with the loaded FXML file
            Scene loginScene = new Scene(loginRoot);

            // Set the new scene on the current stage
            currentStage.setScene(loginScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void handlesignupButtonClick(ActionEvent event) {
        try {
            // Load the new FXML file
            Parent signupRoot = FXMLLoader.load(getClass().getResource("/application/signup.fxml"));

            // Get the current stage
            Stage currentStage = (Stage) login.getScene().getWindow();

            // Create a new scene with the loaded FXML file
            Scene signupScene = new Scene(signupRoot);

            // Set the new scene on the current stage
            currentStage.setScene(signupScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}
