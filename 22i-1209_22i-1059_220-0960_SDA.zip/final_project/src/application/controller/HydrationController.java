package application.controller;

import blayer.HydrationData;
import blayer.WaterEntry;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class HydrationController {

    @FXML
    private TextField waterIntakeField;

    @FXML
    private TextField weightField;

    @FXML
    private ComboBox<String> activityLevelCombo;

    @FXML
    private ComboBox<String> climateCombo;

    @FXML
    private Button calculateButton;

    @FXML
    private Label resultLabel;

    @FXML
    private Button backButton;

    private HydrationData hydrationData;

    @FXML
    public void initialize() {
        hydrationData = new HydrationData();

        activityLevelCombo.setItems(FXCollections.observableArrayList("Easy", "Normal", "Hard"));
        climateCombo.setItems(FXCollections.observableArrayList("Cold", "Moderate", "Hot"));
    }

    @FXML
    private void calculateHydration() {
        try {
            int weight = Integer.parseInt(weightField.getText());
            int dailyIntake = Integer.parseInt(waterIntakeField.getText());
            String activityLevel = activityLevelCombo.getValue();
            String climate = climateCombo.getValue();

            int recommendedIntake = hydrationData.calculateDailyIntake(weight, activityLevel, climate);

            if (dailyIntake > recommendedIntake) {
                int excess = dailyIntake - recommendedIntake;
                resultLabel.setText(String.format("You drank %.2f liters extra. Keep doing well!", excess / 1000.0));
            } else if (dailyIntake < recommendedIntake) {
                int deficit = recommendedIntake - dailyIntake;
                resultLabel.setText(String.format("You need to drink %.2f more liters to keep yourself hydrated.", deficit / 1000.0));
            } else {
                resultLabel.setText("You have met your daily water intake goal. Great job!");
            }

            // Log the water intake entry
            hydrationData.logWaterIntake(new WaterEntry(dailyIntake));
        } catch (NumberFormatException e) {
            resultLabel.setText("Please enter valid numbers.");
        }
    }

    @FXML
    private void handleBackButtonAction() {
        try {
            // Load home.fxml
            Parent homeRoot = FXMLLoader.load(getClass().getResource("/application/home.fxml"));
            Scene homeScene = new Scene(homeRoot);

            // Get the current stage
            Stage currentStage = (Stage) waterIntakeField.getScene().getWindow();

            // Set the new scene
            currentStage.setScene(homeScene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
