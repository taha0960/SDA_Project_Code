package blayer;

import java.util.Arrays;

public class resource {
    
    private String title;
    private String type;
    private String content;
    private byte[] image; // Byte array to store image data
    private String link;  // Link to where the resource should direct when clicked

    public resource(String title, String type, String content, byte[] image, String link) {
        this.title = title;
        this.type = type;
        this.content = content;
        this.image = image;
        this.link = link;
    }

    // Getters and setters for all fields
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    @Override
    public String toString() {
        return "Resource{" +
                "title='" + title + '\'' +
                ", type='" + type + '\'' +
                ", content='" + content + '\'' +
                ", image=" + Arrays.toString(image) +
                ", link='" + link + '\'' +
                '}';
    }
}
