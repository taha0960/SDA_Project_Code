package blayer;

public class healthpal {
    private static healthpal instance;
    private fitnesslibrary fitnessLibrary;

    private healthpal() {
        // Private constructor to prevent instantiation from outside
    }

    public static healthpal getInstance() {
        if (instance == null) {
            instance = new healthpal();
        }
        return instance;
    }

    public fitnesslibrary getFitnessLibrary() {
        return fitnessLibrary;
    }

    public void setFitnessLibrary(fitnesslibrary fitnessLibrary) {
        this.fitnessLibrary = fitnessLibrary;
    }

    public void createFitnessLibrary() {
        if (fitnessLibrary == null) {
            fitnessLibrary = new fitnesslibrary();
        }
    }
}
