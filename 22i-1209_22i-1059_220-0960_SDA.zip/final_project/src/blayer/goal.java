package blayer;

public class goal {
	
	    private int startWeight;
	    private int goalWeight;
	    private int currentWeight;
	    private double progress;
	    private String username;

    public goal( int startWeight, int goalWeight, int currentWeight, double progress, String username) {
        this.startWeight = startWeight;
        this.goalWeight = goalWeight;
        this.currentWeight = currentWeight;
        this.progress = progress;
        this.username = username;
    }



    public int getStartWeight() {
        return startWeight;
    }

    public void setStartWeight(int startWeight) {
        this.startWeight = startWeight;
        this.progress = calculateProgress();
    }

    public int getGoalWeight() {
        return goalWeight;
    }

    public void setGoalWeight(int goalWeight) {
        this.goalWeight = goalWeight;
        this.progress = calculateProgress();
    }

    public int getCurrentWeight() {
        return currentWeight;
    }

    public void setCurrentWeight(int currentWeight) {
        this.currentWeight = currentWeight;
        this.progress = calculateProgress();
    }

    
    public double getProgress() {
        return progress;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    // Calculate progress based on current weight, start weight, and goal weight
    public double calculateProgress() {
    	
    	    // Calculate progress based on the difference between current weight and start weight
    	    double weightDifference = currentWeight - startWeight;
    	    double goalDifference = goalWeight - startWeight;
    	    
    	    // Ensure progress is within the range [-100, 100]
    	    double progress = (weightDifference / goalDifference) * 100;
    	    return Math.max(-100.0, Math.min(progress, 100.0));
    	
    }



	public void setProgress(double progress2) {
	progress=progress2;
	}
}
