package blayer;





import java.util.List;

public class Nutritionist {
    private String name;
    private String bio;
    private String specialty;
    private List<TimeSlot> availability;

    public Nutritionist(String name, String bio, String specialty, List<TimeSlot> availability) {
        this.name = name;
        this.bio = bio;
        this.specialty = specialty;
        this.availability = availability;
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    public List<TimeSlot> getAvailability() {
        return availability;
    }

    public void setAvailability(List<TimeSlot> availability) {
        this.availability = availability;
    }

    public void bookSession(User user, TimeSlot timeSlot) {
        if (availability.contains(timeSlot)) {
            // Implement booking logic: remove the timeslot from availability and notify the user
            availability.remove(timeSlot);
            user.addBookedTimeSlot(timeSlot);
            System.out.println("Session booked for " + user.getName() + " with " + name + " at " + timeSlot);
        } else {
            System.out.println("Time slot not available.");
        }
    }

    public MealPlan createMealPlan(String userName) {
        MealPlan mealPlan = new MealPlan();
        // Implement meal plan creation logic based on user's goals, preferences, and restrictions
        // For demonstration, adding sample meals:
        mealPlan.addBreakfast("Oatmeal with fruits");
        mealPlan.addLunch("Grilled chicken salad");
        mealPlan.addDinner("Steamed vegetables with quinoa");
        mealPlan.addSnack("Greek yogurt with honey");

        return mealPlan;
    }


    public void provideNutritionGuidance(User user) {
        // Implement nutrition guidance logic based on user's goals and health data
        System.out.println("Providing nutrition guidance to " + user.getName());
        // Example guidance
        System.out.println("Eat more vegetables and fruits, and reduce sugar intake.");
    }
}
