package blayer;
import java.util.List;
import blayer.resource;

public class category {
    private String name;
    private List<resource> resources;


    public category(String name) {
        this.name = name;
        
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<resource> getResources() {
        return resources;
    }

    public void setResources(List<resource> resources) {
        this.resources = resources;
    }
}
