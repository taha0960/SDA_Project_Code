package blayer;



import java.time.LocalDate;

public class Event {
    private String name;
    private String location;
    private String cost;
    private String category;
    private LocalDate date;
    private String difficulty;

    public Event(String name, String location, String cost, String category, LocalDate date, String difficulty) {
        this.name = name;
        this.location = location;
        this.cost = cost;
        this.category = category;
        this.date = date;
        this.difficulty = difficulty;
    }

    // Getters
    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    public String getCost() {
        return cost;
    }

    public String getCategory() {
        return category;
    }

    public LocalDate getDate() {
        return date;
    }

    public String getDifficulty() {
        return difficulty;
    }

    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    // toString method for displaying event details in ListView
    @Override
    public String toString() {
        return name + " - " + location + " - " + cost;
    }
}
