package blayer;

public class WaterEntry {
    private int amount; // amount in ml

    public WaterEntry(int amount) {
        this.amount = amount;
    }

    public int getAmount() {
        return amount;
    }
}
