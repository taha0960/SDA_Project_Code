package blayer;

import java.util.ArrayList;
import java.util.List;

public class HydrationData {
    private int waterIntakeGoal;
    private List<WaterEntry> waterLog;

    public HydrationData() {
        this.waterLog = new ArrayList<>();
    }

    public void logWaterIntake(WaterEntry entry) {
        this.waterLog.add(entry);
    }

    public int calculateDailyIntake(int weight, String activityLevel, String climate) {
        int baseIntake = weight * 30; // basic intake in ml (30 ml per kg)

        switch (activityLevel.toLowerCase()) {
            case "normal":
                baseIntake += 500; // add 500 ml for normal activity
                break;
            case "hard":
                baseIntake += 1000; // add 1000 ml for hard activity
                break;
        }

        switch (climate.toLowerCase()) {
            case "hot":
                baseIntake += 500; // add 500 ml for hot climate
                break;
            case "cold":
                baseIntake -= 500; // reduce 500 ml for cold climate
                break;
        }

        this.waterIntakeGoal = baseIntake;
        return this.waterIntakeGoal;
    }

    public int getWaterIntakeGoal() {
        return waterIntakeGoal;
    }

    public List<WaterEntry> getWaterLog() {
        return waterLog;
    }
}
