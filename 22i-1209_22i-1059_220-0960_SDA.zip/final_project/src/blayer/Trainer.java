package blayer;

import java.util.List;

public class Trainer {
    private String name;
    private String bio;
    private String specialty;
    private List<TimeSlot> availability;

    public Trainer(String name, String bio, String specialty, List<TimeSlot> availability) {
        this.name = name;
        this.bio = bio;
        this.specialty = specialty;
        this.availability = availability;
    }

    public void bookSession(User user, TimeSlot timeSlot) {
        // Implement session booking logic
        System.out.println("Session booked for " + user.getName() + " at " + timeSlot);
    }

    public void designWorkoutPlan(User user) {
        // Implement workout plan design logic
        System.out.println("Workout plan designed for " + user.getName());
    }

    public void assignWorkoutPlan(User user) {
        // Implement workout plan assignment logic
        System.out.println("Workout plan assigned to " + user.getName());
    }

    public String getPostWorkoutPlan(User user, String selectedPlan) {
        // Logic to generate post-workout plan based on user and selected plan
        // For example:
        String postWorkoutPlan = "";
        if (selectedPlan.equals("Plan A(Morning)")) {
            postWorkoutPlan = "Post-workout plan for Plan A: Stretch for 10 minutes, drink protein shake.";
        } else if (selectedPlan.equals("Plan B(Evening)")) {
            postWorkoutPlan = "Post-workout plan for Plan B: Foam roll for 5 minutes, have a balanced meal.";
        } else if (selectedPlan.equals("Plan C(Night)")) {
            postWorkoutPlan = "Post-workout plan for Plan C: Take a cold shower, replenish electrolytes.";
        }
        return postWorkoutPlan;
    }

    public void notifyUser(User user) {
        // Implement user notification logic
        System.out.println("User " + user.getName() + " has been notified.");
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public String getBio() {
        return bio;
    }

    public String getSpecialty() {
        return specialty;
    }

    public List<TimeSlot> getAvailability() {
        return availability;
    }
}
