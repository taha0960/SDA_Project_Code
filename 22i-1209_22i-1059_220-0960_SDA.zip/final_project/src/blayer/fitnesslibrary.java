package blayer;

import java.util.ArrayList;
import java.util.List;
import blayer.category;
import dblayer.dbconnect;
public class fitnesslibrary {
    private List<category> categories;


    public fitnesslibrary() {
        this.categories = new ArrayList<>();
        initializeLibrary();
    }

    private void initializeLibrary() {
        // Fetch all categories from the database
        List<String> categoryNames = dbconnect.getInstance().getAllCategoryNames();
        
        // For each category, fetch resources and create Category objects
        for (String categoryName : categoryNames) {
            category category = new category(categoryName);
            
            // Fetch resources for the current category from the database
            List<resource> resources = dbconnect.getInstance().getResourcesByCategory(categoryName);
            
            // Add resources to the category object
            category.setResources(resources);
            
            // Add the category object to the fitness library
            categories.add(category);
        }
    }
    
    public List<String> getCategories() {
        List<String> categoryNames = new ArrayList<>();
        for (category cat : categories) {
            categoryNames.add(cat.getName());
        }
        return categoryNames;
    }
    
    public List<resource> getResourcesByCategory(String categoryName) {
        for (category cat : categories) {
            if (cat.getName().equalsIgnoreCase(categoryName)) {
                return cat.getResources();
            }
        }
        return new ArrayList<>(); // Return an empty list if the category is not found
    }
}
