package blayer;

import java.util.ArrayList;
import java.util.List;

public class User {
    private String username;
    private String password;
    private String name;
    private int age;
    private double height;
    private double weight;
    private int activityLevel;
    private List<String> dietaryPreferences;
    private List<String> allergies;
    private String dietaryGoal; // e.g., weight loss, muscle gain
    private String preferences; // e.g., vegetarian, low-carb
    private List<TimeSlot> bookedTimeSlots;

    public User(String username, String password, String name, int age, double height, double weight, int activityLevel, List<String> dietaryPreferences, List<String> allergies) {
        this.username = username;
        this.password = password;
        this.name = name;
        this.age = age;
        this.height = height;
        this.weight = weight;
        this.activityLevel = activityLevel;
        this.dietaryPreferences = dietaryPreferences;
        this.allergies = allergies;
    
        this.bookedTimeSlots = new ArrayList<>();
    }

    // Getters and Setters

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public int getActivityLevel() {
        return activityLevel;
    }

    public void setActivityLevel(int activityLevel) {
        this.activityLevel = activityLevel;
    }

    public List<String> getDietaryPreferences() {
        return dietaryPreferences;
    }

    public void setDietaryPreferences(List<String> dietaryPreferences) {
        this.dietaryPreferences = dietaryPreferences;
    }

    public List<String> getAllergies() {
        return allergies;
    }

    public void setAllergies(List<String> allergies) {
        this.allergies = allergies;
    }

    public String getDietaryGoal() {
        return dietaryGoal;
    }

    public void setDietaryGoal(String dietaryGoal) {
        this.dietaryGoal = dietaryGoal;
    }
    public List<TimeSlot> getBookedTimeSlots() {
        return bookedTimeSlots;
    }
    public void addBookedTimeSlot(TimeSlot timeSlot) {
        this.bookedTimeSlots.add(timeSlot);
    }
    public String getPreferences() {
        return preferences;
    }

    public void setPreferences(String preferences) {
        this.preferences = preferences;
    }
}
