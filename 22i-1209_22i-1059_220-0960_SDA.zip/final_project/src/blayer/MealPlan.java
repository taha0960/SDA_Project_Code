package blayer;



import java.util.ArrayList;
import java.util.List;

public class MealPlan {
    private List<String> breakfast;
    private List<String> lunch;
    private List<String> dinner;
    private List<String> snacks;

    public MealPlan() {
        this.breakfast = new ArrayList<>();
        this.lunch = new ArrayList<>();
        this.dinner = new ArrayList<>();
        this.snacks = new ArrayList<>();
    }

    public List<String> getBreakfast() {
        return breakfast;
    }

    public void setBreakfast(List<String> breakfast) {
        this.breakfast = breakfast;
    }

    public List<String> getLunch() {
        return lunch;
    }

    public void setLunch(List<String> lunch) {
        this.lunch = lunch;
    }

    public List<String> getDinner() {
        return dinner;
    }

    public void setDinner(List<String> dinner) {
        this.dinner = dinner;
    }

    public List<String> getSnacks() {
        return snacks;
    }

    public void setSnacks(List<String> snacks) {
        this.snacks = snacks;
    }

    // Methods to add meals to the plan
    public void addBreakfast(String meal) {
        breakfast.add(meal);
    }

    public void addLunch(String meal) {
        lunch.add(meal);
    }

    public void addDinner(String meal) {
        dinner.add(meal);
    }

    public void addSnack(String snack) {
        snacks.add(snack);
    }

    // Method to customize the plan by swapping meals
    public void swapMeal(String mealType, int index, String newMeal) {
        switch (mealType.toLowerCase()) {
            case "breakfast":
                if (index >= 0 && index < breakfast.size()) {
                    breakfast.set(index, newMeal);
                }
                break;
            case "lunch":
                if (index >= 0 && index < lunch.size()) {
                    lunch.set(index, newMeal);
                }
                break;
            case "dinner":
                if (index >= 0 && index < dinner.size()) {
                    dinner.set(index, newMeal);
                }
                break;
            case "snacks":
                if (index >= 0 && index < snacks.size()) {
                    snacks.set(index, newMeal);
                }
                break;
            default:
                throw new IllegalArgumentException("Invalid meal type: " + mealType);
        }
    }

    // Method to adjust portion sizes (assuming the portion is described as a string)
    public void adjustPortion(String mealType, int index, String newPortion) {
        swapMeal(mealType, index, newPortion);
    }

    // Method to search for alternative recipes (for demonstration purposes, just a stub)
    public List<String> searchAlternativeRecipes(String query) {
        // In a real application, this would involve a database or API call
        List<String> alternatives = new ArrayList<>();
        alternatives.add(query + " Alternative 1");
        alternatives.add(query + " Alternative 2");
        alternatives.add(query + " Alternative 3");
        return alternatives;
    }

    @Override
    public String toString() {
        return "MealPlan{" +
                "breakfast=" + breakfast +
                ", lunch=" + lunch +
                ", dinner=" + dinner +
                ", snacks=" + snacks +
                '}';
    }
}
