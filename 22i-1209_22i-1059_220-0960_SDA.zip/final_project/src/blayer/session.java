package blayer;

public class session {
    private static String user;

    public static String getUser() {
        return user;
    }

    public static void setUser(String username) {
        user = username;
    }
    
    public static void removeUser() {
        user = null;
    }
}
